def take_order(name, quantity = 1):
    print(f"Your order is: {name} - {quantity}")

take_order("Khinkali",5)