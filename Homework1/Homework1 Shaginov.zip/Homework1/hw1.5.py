user_text = input("Enter some text: ")
num_symbols = len(user_text)
print(f"Number of symbols: {num_symbols}")