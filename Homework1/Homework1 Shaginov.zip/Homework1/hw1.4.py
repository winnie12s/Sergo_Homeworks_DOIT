fruit1 = input("Enter the first fruit: ")
fruit2 = input("Enter the second fruit: ")
fruit3 = input("Enter the third fruit: ")

result = f"{fruit1}//{fruit2}%%{fruit3}"
print(result)