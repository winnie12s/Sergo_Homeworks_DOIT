num1 = int(input("Enter your number 1: "))
num2 = int(input("Enter your number 2: "))

num3 = num1**num2

print(num3)