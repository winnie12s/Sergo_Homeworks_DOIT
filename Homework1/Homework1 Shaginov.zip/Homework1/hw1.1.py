name = input("Enter your name: ")
surname = input("Enter your surname: ")

print("Your name and surname is: ",name, surname)